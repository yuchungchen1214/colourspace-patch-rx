
[HCFR_Devices#PLAT#]
"Colorimtre HCFR V3.1 (Argyll)" = LIBUSB0_DEV, USB\VID_04DB&PID_005B
"Colorimtre HCFR V4.0 (Argyll)" = LIBUSB0_DEV, USB\VID_04D8&PID_FE17

[Sequel_Devices#PLAT#]
"Eye-One Display 1 (Argyll)"    = LIBUSB0_DEV, USB\VID_0670&PID_0001

[X_Rite_Devices#PLAT#]
"HueyL (Argyll)"                = LIBUSB0_DEV, USB\VID_0765&PID_5001
"HueyL (Argyll)"                = LIBUSB0_DEV, USB\VID_0765&PID_5010
;"Eye-One Display 3 (Argyll)"    = LIBUSB0_DEV, USB\VID_0765&PID_5020
"ColorMunki Smile (Argyll)"     = LIBUSB0_DEV, USB\VID_0765&PID_6003
"i1 Studio (Argyll)"            = LIBUSB0_DEV, USB\VID_0765&PID_6008
"i1 Pro3 (Argyll)"              = LIBUSB0_DEV, USB\VID_0765&PID_6009
;"D123 (Argyll)"                 = LIBUSB0_DEV, USB\VID_0765&PID_600A
"DTP20 (Argyll)"                = LIBUSB0_DEV, USB\VID_0765&PID_D020
"DTP92Q (Argyll)"               = LIBUSB0_DEV, USB\VID_0765&PID_D092
"DTP94 (Argyll)"                = LIBUSB0_DEV, USB\VID_0765&PID_D094

[ColorVision_Devices#PLAT#]
"Spyder1 (Argyll)"              = LIBUSB0_DEV, USB\VID_085C&PID_0100
"Spyder2 (Argyll)"              = LIBUSB0_DEV, USB\VID_085C&PID_0200
"Spyder3 (Argyll)"              = LIBUSB0_DEV, USB\VID_085C&PID_0300
"Spyder4 (Argyll)"              = LIBUSB0_DEV, USB\VID_085C&PID_0400
"Spyder5 (Argyll)"              = LIBUSB0_DEV, USB\VID_085C&PID_0500
"SpyderX (Argyll)"              = LIBUSB0_DEV, USB\VID_085C&PID_0A00
"SpyderX2 (Argyll)"             = LIBUSB0_DEV, USB\VID_085C&PID_0A0A
"Spyder2024 (Argyll)"           = LIBUSB0_DEV, USB\VID_085C&PID_0A0B

[GM_X_Rite_Devices#PLAT#]
"Eye-One Pro (Argyll)"          = LIBUSB0_DEV, USB\VID_0971&PID_2000
"Eye-One Monitor (Argyll)"      = LIBUSB0_DEV, USB\VID_0971&PID_2001
"Eye-One Display 2 (Argyll)"    = LIBUSB0_DEV, USB\VID_0971&PID_2003
"Huey (Argyll)"                 = LIBUSB0_DEV, USB\VID_0971&PID_2005
"ColorMunki (Argyll)"           = LIBUSB0_DEV, USB\VID_0971&PID_2007

[Hughski_Devices#PLAT#]
"ColorHug 2 (Argyll)"           = LIBUSB0_DEV, USB\VID_273F&PID_1004
"ColorHug (Argyll)"             = LIBUSB0_DEV, USB\VID_273F&PID_1001
"ColorHug (Argyll)"             = LIBUSB0_DEV, USB\VID_04D8&PID_F8DA

[ImageEngineering_Devices#PLAT#]
"EX1 (Argyll)"                  = LIBUSB0_DEV, USB\VID_2457&PID_4000

